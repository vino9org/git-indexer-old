## casa-account-v2
casa-account service implementation v2 written in nodejs. currently it only returns dummy data.
